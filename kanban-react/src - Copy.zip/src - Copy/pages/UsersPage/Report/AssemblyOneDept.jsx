import React from 'react'

const AssemblyOneDept = () => {
  return (
    <div>AssemblyOneDept</div>
  )
}

export default AssemblyOneDept