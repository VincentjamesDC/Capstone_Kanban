import React from 'react'

const AssemblyTwoDept = () => {
  return (
    <div>AssemblyTwoDept</div>
  )
}

export default AssemblyTwoDept