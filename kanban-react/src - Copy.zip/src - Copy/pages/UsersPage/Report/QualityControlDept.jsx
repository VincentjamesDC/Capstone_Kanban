import React from 'react'

const QualityControlDept = () => {
  return (
    <div>QualityControlDept</div>
  )
}

export default QualityControlDept