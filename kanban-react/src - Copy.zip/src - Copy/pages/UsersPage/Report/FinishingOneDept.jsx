import React from 'react'

const FinishingOneDept = () => {
  return (
    <div>FinishingOneDept</div>
  )
}

export default FinishingOneDept