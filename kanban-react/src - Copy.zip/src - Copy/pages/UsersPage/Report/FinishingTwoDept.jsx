import React from 'react'

const FinishingTwoDept = () => {
  return (
    <div>FinishingTwoDept</div>
  )
}

export default FinishingTwoDept