import React from 'react'

const PrepDept = () => {
  return (
    <div>PrepDept</div>
  )
}

export default PrepDept